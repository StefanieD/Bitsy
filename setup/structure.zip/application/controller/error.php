<?php

class Controller_Error extends Bitsy_Controller_Abstract {

    public function index_Action() {
    }

}
