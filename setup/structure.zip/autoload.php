<?php

//creates new autoloader for project
function my_autoload($className) 
{
    $path = Bitsy_Config::getProjectClasses() . "/" . 
    strtolower(str_replace("_", "/", $className)) . ".php";
    if (file_exists($path)) {
        require_once($path);
    }
}

Bitsy_Autoload::register('my_autoload');