<?php

error_reporting(E_ALL | E_NOTICE);

require_once(dirname(__FILE__) . '/../../bitsy-projekt/base_config.php');
require_once(dirname(__FILE__) . '/../autoload.php');

date_default_timezone_set('Europe/Berlin');

$request =  Bitsy_Http_Request::getInstance();
$response = Bitsy_Http_Response::getInstance();

Bitsy_Config::readINI("../config/config.ini");     
Bitsy_FrontController::call($request, $response);